<!-- DB connection -->

<?php
ob_start();
session_start();

include("../backend/admin/config.php");
// include("../backend/admin/functions.php");
$error_message = '';
$success_message = '';
?>
<?php
$BASE_URL = 'http://localhost/vasantham/vasantham-master';

// Check the page slug is valid or not.
$statement = $pdo->prepare("SELECT * FROM department");
$statement->execute();
$departmentList = $statement->fetchAll();
$total = $statement->rowCount();
if ($total == 0) {
    header('location: ' . $BASE_URL);
    //echo 'no rows available';
    exit;
} else {
    //echo $departmentList[0]['dep_name'];
}
?>

<?php
include "header.php"
?>

<?php
/* Preventing the direct access of this page.
if (!isset($_REQUEST['slug'])) {
    header('location: ' . BASE_URL);
    exit;
}*/

// Getting the news detailed data from the news id
$statement = $pdo->prepare("SELECT
							t1.news_title,
							t1.news_slug,
							t1.news_content,
							t1.news_date,
							t1.publisher,
							t1.photo,
							t1.category_id,
							t2.category_id,
							t2.category_name,
							t2.category_slug

                           	FROM news t1
                           	JOIN category t2
                           	ON t1.category_id = t2.category_id");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);
foreach ($result as $row) {
    $news_title    = $row['news_title'];
    $news_content  = $row['news_content'];
    $news_date     = $row['news_date'];
    $publisher     = $row['publisher'];
    $photo         = $row['photo'];
    $category_id   = $row['category_id'];
    $category_slug = $row['category_slug'];
    $category_name = $row['category_name'];
}

// Update data for view count for this news page
// Getting current view count
$statement = $pdo->prepare("SELECT * FROM news");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);
foreach ($result as $row) {
    $current_total_view = $row['total_view'];
}
$updated_total_view = $current_total_view + 1;

// Updating database for view count
$statement = $pdo->prepare("UPDATE news SET total_view=? WHERE news_slug=?");
$statement->execute(array($updated_total_view, $_REQUEST['slug']));
?>

<body>
    <div class="page-wrapper">

        <!-- Preloader -->
        <div class="preloader"></div>
        <?php
        include "header_main.php"
        ?>
        <!--Page Title-->
        <section class="page-title" style="background-image: url(images/background/8.jpg);">
            <div class="auto-container">
                <div class="title-outer">
                    <h1>Contact Us</h1>
                    <ul class="page-breadcrumb">
                        <li><a href="index.php">Home</a></li>
                        <li>Contact</li>
                    </ul>
                </div>
            </div>
        </section>
        <!--End Page Title-->
        
        <!-- Blog Start -->
        <section class="blog">
            <div class="container">
                <div class="row">
                    <div class="col-md-9">

                        <!-- Blog Classic Start -->
                        <div class="blog-grid">
                            <div class="row">
                                <div class="col-md-12">


                                    <!-- Post Item Start -->
                                    <div class="post-item">
                                        <div class="image-holder">
                                            <img class="img-responsive" src="<?php echo BASE_URL; ?>assets/uploads/<?php echo $photo ?>" alt="<?php echo $news_title; ?>">
                                        </div>
                                        <div class="text">
                                            <h3><?php echo $news_title; ?></h3>
                                            <ul class="status">
                                                <li><i class="fa fa-tag"></i>Category: <a href="<?php echo BASE_URL; ?>category/<?php echo $category_slug; ?>"><?php echo $category_name; ?></a></li>
                                                <li><i class="fa fa-calendar"></i>Date: <?php echo $news_date; ?></li>
                                            </ul>
                                            <p>
                                                <?php echo $news_content; ?>
                                            </p>
                                            <h3>Share This</h3>
                                            <div class="sharethis-inline-share-buttons"></div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3>Comments</h3>
                                            <?php
                                            // Getting the full url of the current page
                                            // $final_url = BASE_URL . 'news/' . $_REQUEST['slug'];
                                            ?>
                                            <!-- Facebook Comment Main Code (got from facebook website) -->
                                            <div class="fb-comments" data-href="<?php echo $final_url; ?>" data-numposts="5"></div>
                                        </div>
                                    </div>
                                    <!-- Post Item End -->

                                </div>

                            </div>
                        </div>
                        <!-- Blog Classic End -->
                    </div>
                </div>
            </div>
        </section>
        <!-- Blog End -->
<!-- Main Footer -->
<?php
        include "footer.php"
        ?>
        <!--End Main Footer -->

    </div><!-- End Page Wrapper -->

    <?php
    // include "color-switcher.php";
    include "script_includes.php";
    ?>
</body>

</html>