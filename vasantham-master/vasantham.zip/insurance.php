<?php
include "header.php"
?>
<style>
    #customers {
        font-family: Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 30%;
    }

    #customers td,
    #customers th {
        border: 1px solid #eee;
        padding: 8px;
        text-align: center;
    }

    #customers tr:nth-child(even) {
        background-color: #ECF7E6;
    }

    #customers tr:nth-child(odd) {
        background-color: #FFFFFF;
    }

    #customers tr:hover {
        background-color: #C6D3F3;
    }

    /*#customers tr:hover {background-color:#f1f1f1;}*/


    #customers th {

        padding-top: 12px;
        padding-bottom: 12px;
        text-align: center;
        background-color: #1370B5;
        color: white;
    }
</style>


<body>

    <div class="page-wrapper">

        <!-- Preloader -->
        <div class="preloader"></div>

        <!-- Main Header-->
        <?php
        include "header_main.php"
        ?>
        <!--End Main Header -->
        <!--Page Title-        <section class="page-title" style="background-image: url(images/background/8.jpg);">
            <div class="auto-container">
                <div class="title-outer">
                    <h1>Gallery</h1>
                    <ul class="page-breadcrumb">
                        <li><a href="index-2.php">Home</a></li>
                        <li>Gallery</li>
                    </ul>
                </div>
            </div>
        </section>
        <End Page Title------------------------------------------------------------------------------>
            <!------------------------------------------------------------------------------------------->

           <!------------------------------------------------------------------------------------------------>
        <!------------------------------------------------------------------------------------------------>
        <!------------------------------------TABLE----------------------------------------------------->

       
        <h3 style="border: black; text-align:center;color:#1370B5"> Our Services</h3><br>
        <center>
            <table id="customers" style="align-self: center;">

                <tr>
                    <td style="font-size: 14px;">Chief Minister's Comprehensive Health Insurance Scheme</td>
                </tr>
                <tr>
                    <td>TNNHIS MidInida Health Service</td>
                </tr>
                <tr>
                    <td>Rashtriya Swasthya Bima Yojana</td>
             </tr>
                <tr>
                    <td>Employee State Insurance Act </td>
                    </tr>
                <tr>
                    <td>ESI Pension and Employees</td>
                    </tr>
                
                <tr>  <td>Nuclear power corporation of India LTD</td></tr>
                <tr><td>Indin Rare Earth Limited(IREL)</td></tr>
                <tr> <td>Indian Space Research Organization(ISRO)</td>  </tr>
                <tr> <td> Vidal Health Insurance TPA</td>  </tr>
                <tr> <td>Dedicated Healthcare services TPA(DHS)</td>  </tr>
                <tr> <td>E-Meditek Soultion Limited</td>  </tr>
                <tr> <td>Family Health Plan Limited</td>  </tr>
                <tr> <td>ICICI Lombard General Insurance Co.LTD</td>  </tr>
                <tr> <td>Life Insurance Corporation of India</td>  </tr>
                <tr> 
                  <td>  Max New York Life Insurance</td>  </tr>
                <tr> <td>MEDI Assist India LTD</td>  </tr>
                <tr> <td>National Insurance Company</td>  </tr>
                <tr> <td>Paramound Health Group</td>  </tr>
                <tr> <td>Reliance Health Insurance Limited</td> </tr> 
                <tr> <td>Star Health and Allied Insurance Limited</td>  </tr>
                <tr> <td>United HealthCare/td>  </tr>
                <tr> <td>United India Insurance</td> </tr> 
                <tr> <td>Religare Health Insurance</td>  </tr>
                <tr> <td>Bajaj Allianz Health Insurance</td>  </tr>
                <tr> <td>Cignattk health Insurance</td>  </tr>
                <tr> <td>HDFC ERGO Health Insurance</td>  </tr>
                <tr> <td>Chola MS Health Insurance</td>  </tr>
                <tr> <td>Ericson TPA Serices PVT</td>  </tr>
                <tr> <td> SBI General Insurance</td>  </tr>
                <tr> <td>MAX BUPA Health Insurance </td>  </tr>
                <tr> <td>Health India Insurance</td>  </tr>
                <tr> <td>Medsava Health Care LTd</td>  </tr>
                <tr> <td>Apollo Munich Health Insurance</td></tr> 
                <tr> <td> IFFCO-Tokio Health Insurance</td> </tr>
                <tr> <td> Vipul Medcorp TPA PVT LTD</td> </tr>
                <tr> <td> Raksha TPA PVT LTD</td> </tr>
                <tr> <td>Universal Sampo General Insurance Co.LTD</td> </tr>
                <tr> <td>Good Health Service TPA Services LTD</td> </tr>
                <tr> <td> Future General Insurance</td> </tr>
                <tr> <td>Medicare TPA Services PVT LTD</td> </tr>
                <tr> <td> Heritage</td> </tr>
                <tr> <td>Aditya Birla Health Insurance </td></tr>
                <tr> <td> Liberty Health Insurance</td></tr>
                <tr> <td> Ericson Insurance </td></tr>

            </table>
        </center>
        <br>
        <!------------------------------------------------------------------------------------------------>
        <!------------------------------------------------------------------------------------------------>
        <!------------------------------------------------------------------------------------------------>




















 <!------------------------------------------------------------------------------------------->
            <!-- Main Footer------------------------------------------------------------------------------ -->
        <?php
        include "footer.php";
        ?>
        <!--End Main Footer -->

    </div><!-- End Page Wrapper -->

    <script src="js/jquery.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.fancybox.js"></script>
    <script src="js/jquery.modal.min.js"></script>
    <script src="js/mmenu.polyfills.js"></script>
    <script src="js/mmenu.js"></script>
    <script src="js/appear.js"></script>
    <script src="js/mixitup.js"></script>
    <script src="js/owl.js"></script>
    <script src="js/wow.js"></script>
    <script src="js/script.js"></script>
    <!-- Color Setting -->
    <script src="js/color-settings.js"></script>
</body>

</html>