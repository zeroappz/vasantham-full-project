<section class="clients-section">
    <div class="auto-container">

        <!-- Sponsors Outer -->
        <div class="sponsors-outer">
            <!--clients carousel-->
            <ul class="clients-carousel owl-carousel owl-theme">
                <li class="slide-item"> <a href="#"><img src="images/clients/1.png" alt="" style="width: 140px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/2.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/3.jpg" alt="" style="width: 140px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/4.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/5.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/6.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/7.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/8.jpg" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/9.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/10.jpg" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/11.jpg" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/12.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/13.jpg" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/14.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/15.jpeg" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/16.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/17.jpg" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/18.jpg" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/19.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/20.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/21.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/22.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/23.jpg" alt="" style="width: 100px; height:100px;"></a> </li>
            
                <li class="slide-item"> <a href="#"><img src="images/clients/18.jpg" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/19.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/20.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/21.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/22.png" alt="" style="width: 100px; height:100px;"></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/clients/23.jpg" alt="" style="width: 100px; height:100px;"></a> </li>
            
            
            </ul>
        </div>
    </div>
</section>